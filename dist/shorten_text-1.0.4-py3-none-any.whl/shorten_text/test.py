from shorten import shorten_text

print(shorten_text("Krishna"))