from setuptools import setup
    
setup(
    name="shorten_text",
    version="1.0.4",
    description="shorten the text",
    packages=['shorten_text'],
    url='https://github.com/projecta-auth/Pypi_test_publish.git',
    author="Krishna",
    license='MIT',
)