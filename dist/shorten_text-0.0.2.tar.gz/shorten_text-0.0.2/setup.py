from setuptools import setup

setup(
    name="shorten_text",
    version="0.0.2",
    description="shorten the text",
    packages=['shorten_text'],
    author="Krishna",
)